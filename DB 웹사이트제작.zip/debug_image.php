<!-- <?php
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL 쿼리 작성
$sql = "SELECT room_pk, room_name, room_site, room_cost, room_text, room_image FROM room";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<h2>Room ID: " . $row["room_pk"] . "</h2>";
        echo "<p>Name: " . htmlspecialchars($row["room_name"]) . "</p>";
        echo "<p>Site: " . htmlspecialchars($row["room_site"]) . "</p>";
        echo "<p>Cost: " . htmlspecialchars($row["room_cost"]) . "</p>";
        echo "<p>Text: " . htmlspecialchars($row["room_text"]) . "</p>";
        echo '<p>Image (base64): <textarea rows="5" cols="50">' . base64_encode($row["room_image"]) . '</textarea></p>';
        echo '<p><img src="data:image/jpeg;base64,' . base64_encode($row["room_image"]) . '" alt="' . htmlspecialchars($row["room_name"]) . '"></p>';
        echo "<hr>";
    }
} else {
    echo "0 results";
}

$conn->close();
?> -->
