// scripts.js

const rooms = [
    { name: "Room A", price: 50000, neighborhood: "Gangnam", image: "https://via.placeholder.com/150", description: "Nice room in Gangnam." },
    { name: "Room B", price: 45000, neighborhood: "Hongdae", image: "https://via.placeholder.com/150", description: "Cozy room in Hongdae." },
    { name: "Room A", price: 50000, neighborhood: "Gangnam", image: "https://via.placeholder.com/150", description: "Nice room in Gangnam." },
    { name: "Room B", price: 45000, neighborhood: "Hongdae", image: "https://via.placeholder.com/150", description: "Cozy room in Hongdae." },
    { name: "Room A", price: 50000, neighborhood: "Gangnam", image: "https://via.placeholder.com/150", description: "Nice room in Gangnam." },
    { name: "Room B", price: 45000, neighborhood: "Hongdae", image: "https://via.placeholder.com/150", description: "Cozy room in Hongdae." },
    { name: "Room A", price: 50000, neighborhood: "Gangnam", image: "https://via.placeholder.com/150", description: "Nice room in Gangnam." },
    { name: "Room B", price: 45000, neighborhood: "Hongdae", image: "https://via.placeholder.com/150", description: "Cozy room in Hongdae." },
    // 추가 예시 데이터를 여기에 포함할 수 있습니다.
];

let currentPage = 1;
const itemsPerPage = 20;

function searchRooms() {
    const roomName = document.getElementById('searchRoomName').value.toLowerCase();
    const neighborhood = document.getElementById('searchNeighborhood').value.toLowerCase();
    const filteredRooms = rooms.filter(room => 
        room.name.toLowerCase().includes(roomName) && 
        room.neighborhood.toLowerCase().includes(neighborhood)
    );
    renderRoomList(filteredRooms);
    renderPagination(filteredRooms.length);
}

function renderRoomList(roomData) {
    const roomList = document.getElementById('roomList');
    roomList.innerHTML = '';
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const currentRooms = roomData.slice(start, end);

    currentRooms.forEach(room => {
        const roomItem = document.createElement('div');
        roomItem.className = 'room-item';
        roomItem.innerHTML = `
            <img src="${room.image}" alt="${room.name}" style="width: 100%; height: auto;">
            <h3>${room.name}</h3>
            <p>${room.neighborhood}</p>
            <p>가격: ${room.price}원</p>
            <p>${room.description}</p>
        `;
        roomList.appendChild(roomItem);
    });
}

function renderPagination(totalItems) {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = '';
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    for (let i = 1; i <= totalPages; i++) {
        const pageItem = document.createElement('button');
        pageItem.className = 'btn btn-outline-secondary';
        pageItem.textContent = i;
        pageItem.onclick = function() {
            currentPage = i;
            searchRooms();
        };
        pagination.appendChild(pageItem);
    }
}

function showSellPage() {
    document.getElementById('sellPage').style.display = 'block';
    document.querySelector('.container').style.display = 'none';
}

function hideSellPage() {
    document.getElementById('sellPage').style.display = 'none';
    document.querySelector('.container').style.display = 'block';
}

function submitRoom() {
    const sellForm = document.getElementById('sellForm');
    const formData = new FormData(sellForm);
    const roomName = formData.get('roomName');
    const roomPrice = formData.get('roomPrice');
    const neighborhood = formData.get('neighborhood');
    const roomImage = formData.get('roomImage');
    const roomDescription = formData.get('roomDescription');

    const reader = new FileReader();
    reader.onload = function(e) {
        const room = {
            name: roomName,
            price: roomPrice,
            neighborhood: neighborhood,
            image: e.target.result,
            description: roomDescription
        };
        rooms.push(room);
        alert('원룸이 등록되었습니다.');
        hideSellPage();
        searchRooms();
    };
    reader.readAsDataURL(roomImage);
}

// 초기 원룸 목록 렌더링
searchRooms();
