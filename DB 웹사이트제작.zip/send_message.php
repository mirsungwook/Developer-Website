<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['sender']) && isset($_POST['receiver']) && isset($_POST['message'])) {
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO messages (sender, receiver, `message`) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $sender, $receiver, $message);
    if ($stmt->execute()) {
        echo "Message sent successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
