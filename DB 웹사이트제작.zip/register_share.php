<?php
// 데이터베이스 연결 설정
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("데이터베이스 연결 실패: " . $conn->connect_error);
}

// POST 요청에서 데이터 가져오기
$product_name = $_POST['product_name'];
$product_code = $_POST['product_code'];
$product_image = $_FILES['product_image']['tmp_name'];
$product_text = $_POST['product_text'];

// 이미지 파일을 BLOB로 읽어들임
$product_image_data = addslashes(file_get_contents($product_image));

// SQL 쿼리 작성
$sql = "INSERT INTO share (product_name, product_code, product_image, product_text) VALUES ('$product_name', '$product_code', '$product_image_data', '$product_text')";

// 쿼리 실행 및 결과 확인
if ($conn->query($sql) === TRUE) {
    // 나눔 상품이 성공적으로 등록되었습니다를 출력
    echo "나눔 상품이 성공적으로 등록되었습니다. <br>";
    echo '<a href="share.php">나눔 페이지로 돌아가기</a>'; // 나눔 페이지로 이동하기 버튼 출력
} else {
    echo "오류: " . $sql . "<br>" . $conn->error;
}

// 데이터베이스 연결 종료
$conn->close();
?>