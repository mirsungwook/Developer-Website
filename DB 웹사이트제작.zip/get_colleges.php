<?php
// 데이터베이스 연결
$conn = new mysqli('localhost', 'root', 'tjddnr6124', 'project');

// 연결 확인
if ($conn->connect_error) {
    die("연결 실패: " . $conn->connect_error);
}

// 단과대학을 가져오는 SQL 쿼리
$query = "SELECT id, department FROM college";
$result = $conn->query($query);

$colleges = array();
while ($row = $result->fetch_assoc()) {
    $colleges[] = $row;
}

// JSON 형식으로 반환
header('Content-Type: application/json');
echo json_encode($colleges);

// 데이터베이스 연결 종료
$conn->close();
?>
