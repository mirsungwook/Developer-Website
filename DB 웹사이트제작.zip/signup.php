<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입</title>

    <link rel="stylesheet" href="style_signup.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<style>
       .logo a {
            font-weight: bold;
            white-space: nowrap; 
        }

        .footer {
    background-color: #274724;
    color: #fff;
    text-align: center;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
}
body {
            margin: 0;
            padding-bottom: 70px; /* 푸터 높이 */
        }
    </style>

<body>

<nav class="navbar">
        <div class="logo">
            <a href="home.php">KONKUK UNIVERSITY <br></a>
        </div>
        <div class="spacer"></div> 
        <!-- 상단바 코드 일부 -->
        <ul class="nav-links">
            <li><a href="home.php">홈</a></li>
            <li><a href="buy.php">상품 구매</a></li> <!-- 이 부분에 href 속성을 추가하여 sell.html로 이동 -->
            <li><a href="sell.php">상품 판매</a></li>
            <li><a href="share.php">나눔</a></li>
            <li><a href="room.php">원룸</a></li>
        </ul>

        <div class="spacer"></div> <!-- 중간 공간 -->

        <ul class="user-links">
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
                <li><a style="margin-right: -35px; color: white;">환영합니다! <?php echo $_SESSION['name']; ?>님</a></li>
                <li><a class="logout-link" onclick="location.href='logout.php'">[로그아웃]</a></li>
            <?php else: ?>
                <li><a href="login.php">로그인</a></li>
                <li><a href="signup.php">회원가입</a></li> <!-- 회원가입 경로 수정 -->
            <?php endif; ?>
        </ul>
    </nav>


    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center">회원가입</h2>
                <form id="signupForm" action="signup_process.php" method="POST">
                    <div class="mb-3">
                        <label for="id" class="form-label">아이디</label>
                        <input type="text" class="form-control" id="id" name="id" required>
                    </div>
                    <div class="mb-3">
                        <label for="passwords" class="form-label">비밀번호</label>
                        <input type="password" class="form-control" id="passwords" name="passwords" required>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">이름</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="college" class="form-label">단과대학</label>
                        <select class="form-control" id="college" name="college" required>
                            <option value="">선택하세요</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="major" class="form-label">학과</label>
                        <select class="form-control" id="major" name="major" required>
                            <option value="">먼저 단과대학을 선택하세요</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">전화번호</label>
                        <input type="text" class="form-control" id="phone" name="phone" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">회원가입</button>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer mt-5">
        <p>&copy; 2024 장터 게시판. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ppVK6pIqH7Q68/Z0pgVOk3X9YFfhY0BfY4YXppIW0nPzS1TFNfF+Ilhg7wRL6p6h4" crossorigin="anonymous"></script>
    <script>
        // 단과대학 데이터 가져오기
        fetch('get_colleges.php')
            .then(response => response.json())
            .then(data => {
                var collegeSelect = document.getElementById('college');
                data.forEach(function(college) {
                    var option = document.createElement('option');
                    option.value = college.id;
                    option.text = college.department;
                    collegeSelect.appendChild(option);
                });
            });

        // 단과대학 선택 시 학과 데이터 가져오기
        document.getElementById('college').addEventListener('change', function() {
            var collegeId = this.value;
            fetch('get_majors.php?college_id=' + collegeId)
                .then(response => response.json())
                .then(data => {
                    var majorSelect = document.getElementById('major');
                    majorSelect.innerHTML = '<option value="">학과를 선택하세요</option>';
                    data.forEach(function(major) {
                        var option = document.createElement('option');
                        option.value = major.id;
                        option.text = major.major;
                        majorSelect.appendChild(option);
                    });
                });
        });
    </script>
</body>
</html>