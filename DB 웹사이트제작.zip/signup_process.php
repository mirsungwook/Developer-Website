<?php
// 데이터베이스 연결 설정
$servername = "localhost"; // 서버 이름
$username = "root"; // MySQL 사용자 이름
$password = "tjddnr6124"; // MySQL 비밀번호
$dbname = "project"; // 사용할 데이터베이스 이름

// MySQL 연결 생성
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("연결 실패: " . $conn->connect_error);
}

// 회원가입 폼에서 데이터 가져오기 및 데이터 검증
$id = trim($_POST['id']);
$passwords = trim($_POST['passwords']);
$name = trim($_POST['name']);
$college_id = intval($_POST['college']);
$major_id = intval($_POST['major']);
$phone = trim($_POST['phone']);

if (empty($id) || empty($passwords) || empty($name) || empty($college_id) || empty($major_id) || empty($phone)) {
    die("모든 필드를 입력해 주세요.");
}

// 비밀번호 해싱
$hashed_password = password_hash($passwords, PASSWORD_DEFAULT);

// college_id를 department로 변환
$college_query = "SELECT department FROM college WHERE id = ?";
$college_stmt = $conn->prepare($college_query);
$college_stmt->bind_param("i", $college_id);
$college_stmt->execute();
$college_result = $college_stmt->get_result();

if ($college_result->num_rows > 0) {
    $college_row = $college_result->fetch_assoc();
    $department = $college_row['department'];
} else {
    die("잘못된 단과대학 ID입니다.");
}

// major_id를 major로 변환
$major_query = "SELECT major FROM major WHERE id = ?";
$major_stmt = $conn->prepare($major_query);
$major_stmt->bind_param("i", $major_id);
$major_stmt->execute();
$major_result = $major_stmt->get_result();

if ($major_result->num_rows > 0) {
    $major_row = $major_result->fetch_assoc();
    $major = $major_row['major'];
} else {
    die("잘못된 전공 ID입니다.");
}

// SQL 쿼리 작성
$sql = "INSERT INTO member (id, passwords, name, department, major, phone) VALUES (?, ?, ?, ?, ?, ?)";

// SQL 쿼리 준비 및 바인딩
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $id, $hashed_password, $name, $department, $major, $phone);

// SQL 쿼리 실행 및 오류 처리
if ($stmt->execute() === TRUE) {
    // 성공 시 HTML 출력
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>회원가입 성공</title>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
    </head>
    <body>
        <div class='container mt-5'>
            <div class='row justify-content-center'>
                <div class='col-md-6'>
                    <div class='card'>
                        <div class='card-body'>
                            <h5 class='card-title text-center'>회원가입이 완료되었습니다</h5>
                            <p class='card-text text-center'>환영합니다! 이제 로그인할 수 있습니다.</p>
                            <div class='text-center'>
                                <a href='login.php' class='btn btn-primary'>로그인 하기</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>";
} else {
    echo "회원가입 중 오류가 발생했습니다: " . $stmt->error;
}

// 연결 종료
$stmt->close();
$conn->close();
?>
