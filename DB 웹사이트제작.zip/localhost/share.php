
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>나눔</title>

    <link rel="stylesheet" href="style_share.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        /* 챗봇 위젯 버튼 스타일 */
        .chat-widget {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }

        .chat-button {
            width: 60px;
            height: 60px;
            background-color: #007bff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .chat-button img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
        }

        /* 챗봇 윈도우 스타일 */
        .chat-window {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 300px;
            height: 400px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: none;
            flex-direction: column;
        }

        .chat-header {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-header button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }

        .chat-body {
            display: flex;
            flex-direction: row;
            height: 100%;
        }

        .chat-users {
            width: 100px;
            border-right: 1px solid #ccc;
            overflow-y: auto;
        }

        .chat-users .user {
            padding: 10px;
            cursor: pointer;
        }

        .chat-users .user:hover {
            background-color: #f0f0f0;
        }

        .chat-messages {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
        }

        .chat-footer {
            display: flex;
            border-top: 1px solid #ccc;
        }

        .chat-footer input {
            flex: 1;
            padding: 10px;
            border: none;
            border-bottom-left-radius: 10px;
        }

        .chat-footer button {
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-bottom-right-radius: 10px;
        }

        .user-message {
            background-color: #007bff;
            color: white;
            padding: 8px;
            border-radius: 10px;
            margin: 5px 0;
            align-self: flex-end;
            max-width: 80%;
            word-wrap: break-word;
        }

  .footer {
    background-color: #274724;
    color: #fff;
    text-align: center;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

    
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <a href="home.php">KONKUK UNIVERSITY</a>
    </div>
    <div class="spacer"></div>
    <ul class="nav-links">
        <li><a href="home.php">홈</a></li>
        <li><a href="buy.php">상품 구매</a></li>
        <li><a href="sell.php">상품 판매</a></li>
        <li><a href="share.php">나눔</a></li>
        <li><a href="room.php">원룸</a></li>
    </ul>
    <div class="spacer"></div>
    <ul class="user-links">
                            <li><a href="login.html">로그인</a></li>
                <li><a href="signup.php">회원가입</a></li> <!-- 회원가입 경로 수정 -->
                    </ul>
    </nav>

<div class="search-bar">
    <input id="searchInput" type="text" placeholder="찾고 싶은 나눔 물품을 입력해주세요!">
    <button onclick="search()">검색</button>
</div>

<div class="container mt-3">
    <div class="row justify-content-start">
        <div class="col-md-3">
            <a href="register_share.html" class="btn btn-primary">나눔 등록하기</a>
        </div>
    </div>
</div>

<div id="shareList" class="container mt-4">
    <div class="row">
            </div>
</div>

<footer class="footer">
    <p>&copy; 2024 장터 게시판. All Rights Reserved.</p>
</footer>
         <!-- 챗봇 위젯 -->
    <div class="chat-widget">
        <div class="chat-button" id="chatButton">
            <img src="https://search.pstatic.net/sunny/?src=https%3A%2F%2Fpreview.files.api.ogq.me%2Fv1%2Fpreview%2FIMAGE%2F7f527e5f%2F5d5c0f5e725f7%2F084449813.jpg%3Fformat%3Dw1280_cc&type=a340" alt="Chat Icon">
        </div>
        <div class="chat-window" id="chatWindow">
            <div class="chat-header">
                <span>쪽지</span>
                <button id="closeChat">&times;</button>
            </div>
            <div class="chat-body">
                <div class="chat-users" id="chatUsers">
                    <!-- 채팅 대상 목록 -->
                    <div class="user" data-user="user1">사용자 1</div>
                    <div class="user" data-user="user2">사용자 2</div>
                    <!-- 추가 사용자들 -->
                </div>
                <div class="chat-messages" id="chatMessages">
                    <!-- 채팅 메시지 -->
                </div>
            </div>
            <div class="chat-footer">
                <input type="text" placeholder="메시지를 입력하세요..." id="chatInput">
                <button id="sendChat">보내기</button>
            </div>
            <script>
        document.getElementById('chatButton').addEventListener('click', function() {
            document.getElementById('chatWindow').style.display = 'flex';
        });

        document.getElementById('closeChat').addEventListener('click', function() {
            document.getElementById('chatWindow').style.display = 'none';
        });

        const chatUsers = document.querySelectorAll('.chat-users .user');
        chatUsers.forEach(user => {
            user.addEventListener('click', function() {
                const selectedUser = this.getAttribute('data-user');
                loadChatForUser(selectedUser);
            });
        });

        document.getElementById('sendChat').addEventListener('click', function() {
            const chatInput = document.getElementById('chatInput');
            const chatMessages = document.getElementById('chatMessages');
            const message = chatInput.value;

            if (message.trim() !== '') {
                const messageElement = document.createElement('div');
                messageElement.textContent = message;
                messageElement.classList.add('user-message');
                chatMessages.appendChild(messageElement);

                // 로컬 스토리지에 메시지 저장
                const selectedUser = document.querySelector('.chat-users .user.active')?.getAttribute('data-user');
                if (selectedUser) {
                    saveMessage(selectedUser, message);
                }

                chatInput.value = '';

                // 스크롤을 아래로 유지
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        });

        function loadChatForUser(user) {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = ''; // 기존 메시지 삭제

            // 로컬 스토리지에서 메시지를 불러오기
            const messages = JSON.parse(localStorage.getItem(user)) || [];
            messages.forEach(message => {
                const messageElement = document.createElement('div');
                messageElement.textContent = message;
                messageElement.classList.add('user-message');
                chatMessages.appendChild(messageElement);
            });
        }

        // 메시지를 로컬 스토리지에 저장하는 함수
        function saveMessage(user, message) {
            const messages = JSON.parse(localStorage.getItem(user)) || [];
            messages.push(message);
            localStorage.setItem(user, JSON.stringify(messages));
        }

        // 스크롤 이벤트 리스너 추가
        window.addEventListener('scroll', function() {
            let currentScroll = window.pageYOffset || document.documentElement.scrollTop;

            if (currentScroll > lastScrollTop) {
                // 아래로 스크롤할 때
                chatWidget.classList.add('fixed');
                chatWidget.classList.remove('relative');
            } else {
                // 위로 스크롤할 때
                chatWidget.classList.remove('fixed');
                chatWidget.classList.add('relative');
            }
            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
        });
        
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>