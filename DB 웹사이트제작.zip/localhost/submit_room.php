
4<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>원룸 판매하기</title>

    <link rel="stylesheet" href="style_share.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f8f9fa;
        }
        .navbar {
            height: 90px; /* 상단바 크기 */
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #274724; /* 초록색 배경 */
            padding: 10px 20px;
            margin-bottom: 20px; /* 바닥 여백 추가 */
        }
        .navbar a {
            color: #fffffff6; /* 글자 색상 */
            text-decoration: none;
            padding: 14px 20px;
            font-size: 20px; /* 폰트 크기 키우기 a 는 상단바 전체, 클래스 지정은 . */
            display: inline-block; /* 텍스트가 블록 요소처럼 동작하도록 설정 */
            line-height: 25px; /* 상단바의 높이와 동일한 높이로 설정 */
        }
        .navbar a:hover {
            background-color: #d5e8d4; /* 밝은 파스텔 초록색 */
            color: black;
        }
        .navbar .logo a {
            font-size: 24px; /* 원하는 크기로 조절 */
            font-weight: bold;
        }
        .navbar .nav-links, .navbar .user-links {
            display: flex;
            list-style-type: none;
        }
        .navbar .nav-links li, .navbar .user-links li {
            margin: 0 10px;
        }
        .spacer {
            flex-grow: 1; /* 로고랑 상단바 사이 공간 균등 */
            height: 50px; /* 원하는 만큼의 높이 추가 */
        }
        .container {
            margin-top: 50px;
        }
        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-title {
            margin-bottom: 30px;
        }
     
        body {
            margin: 0;
            padding-bottom: 70px; /* 푸터 높이 */
        }

        .footer {
    background-color: #274724;
    color: #fff;
    text-align: center;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
}


    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo">  
        <a href="home.php">KONKUK UNIVERSITY <br></a>
    </div>
    <div class="spacer"></div> 
    <ul class="nav-links">
        <li><a href="home.php">홈</a></li>
        <li><a href="buy.php">상품 구매</a></li>
        <li><a href="sell.html">상품 판매</a></li>
        <li><a href="share.php">나눔</a></li>
        <li><a href="room.php">원룸</a></li>
    </ul>

    <div class="spacer"></div> <!-- 중간 공간 -->

    <ul class="user-links">
        <li><a href="login.html">로그인</a></li>
        <li><a href="signup.php">회원가입</a></li>
    </ul>
</nav>

<div class="container">
    <div class="form-section">
        <h1 class="form-title">원룸 판매등록</h1>
        <form id="productForm" action="register_room.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="roomName">원룸명</label>
                <input type="text" id="roomName" name="room_name" class="form-control" placeholder="예) 예인빌" required>
            </div>
            <div class="form-group">
                <label for="roomSite">장소</label>
                <div class="input-group">
                    <input type="text" id="roomSite" name="room_site" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <label for="roomCost">가격</label>
                <input type="number" id="roomCost" name="room_cost" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="roomImage">원룸 사진</label>
                <input type="file" id="roomImage" name="room_image_data" class="form-control" accept="image/*">
            </div>
            <div class="form-group">
                <label for="roomText">원룸 상세설명</label>
                <textarea id="roomText" name="room_text" class="form-control" rows="5"></textarea>
            </div>
            <div class="editor-note"></div>
            <button type="register_room.php" class="btn btn-primary">원룸 등록</button>
        </form>
    </div>
</div>

<div id="shareList" class="container mt-4"></div>

<footer class="footer">
    <p>&copy; 2024 장터 게시판. All Rights Reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
