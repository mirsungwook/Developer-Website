<?php
session_start(); // 세션 시작
?>

<nav class="navbar">
    <div class="logo">
        <a href="home.php">KONKUK UNIVERSITY <br></a>
    </div>
    <div class="spacer"></div> 
    <!-- 상단바 코드 일부 -->
    <ul class="nav-links">
        <li><a href="home.php">홈</a></li>
        <li><a href="buy.php">상품 구매</a></li> <!-- 이 부분에 href 속성을 추가하여 sell.html로 이동 -->
        <li><a href="sell.php">상품 판매</a></li>
        <li><a href="share.php">나눔</a></li>
        <li><a href="room.php">원룸</a></li>
    </ul>

    <div class="spacer"></div> <!-- 중간 공간 -->

    <ul class="user-links">
        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li><a href="logout.php">로그아웃</a></li>
            <?php if (isset($_SESSION['name'])): ?>
                <li><a>환영합니다, <?php echo $_SESSION['name']; ?>님</a></li>
            <?php endif; ?>
        <?php else: ?>
            <li><a href="login.php">로그인</a></li>
            <li><a href="signup.php">회원가입</a></li> <!-- 회원가입 경로 수정 -->
        <?php endif; ?>
    </ul>
</nav>
