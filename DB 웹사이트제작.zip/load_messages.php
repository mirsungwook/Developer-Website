<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 로그인 상태 확인
if (!isset($_SESSION['name'])) {
    echo json_encode([]);
    exit;
}

$user = $_SESSION['name'];
$seller = $_GET['seller'];


$sql = "SELECT * FROM messages WHERE (`name` = ? AND seller = ?) OR (`name` = ? AND seller = ?) ORDER BY time ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $seller, $name, $seller);
$stmt->execute();
$result = $stmt->get_result();

$messages = array();
while($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($messages);
?>
