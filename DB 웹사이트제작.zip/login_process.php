<?php
session_start(); // 세션 시작

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = mysqli_connect('localhost', 'root', 'tjddnr6124', 'project');

    if (!$conn) {
        die('Database connection failed: ' . mysqli_connect_error());
    }

    // 사용자가 입력한 ID와 비밀번호
    $input_id = mysqli_real_escape_string($conn, $_POST['id']);
    $input_pw = mysqli_real_escape_string($conn, $_POST['passwords']);

    // SQL 쿼리 작성
    $sql = "SELECT id, passwords, name FROM member WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $input_id);

    // SQL 쿼리 실행
    $stmt->execute();
    $stmt->store_result();

    // 결과 가져오기
    $stmt->bind_result($db_id, $db_passwords, $name);
    $stmt->fetch();

    // 비밀번호 확인 및 로그인 처리
    if ($stmt->num_rows == 1 && password_verify($input_pw, $db_passwords)) {
        // 로그인 성공 시 세션 변수 설정
        $_SESSION['loggedin'] = true;
        $_SESSION['id'] = $input_id;
        $_SESSION['name'] = $name;
        header("Location: home.php");
        exit();
    } else {
        // 로그인 실패 시 메시지 출력
        echo "<!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>로그인 실패</title>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
        </head>
        <body>
            <div class='container mt-5'>
                <div class='row justify-content-center'>
                    <div class='col-md-6'>
                        <div class='card'>
                            <div class='card-body'>
                                <h5 class='card-title text-center'>로그인 실패</h5>
                                <p class='card-text text-center'>아이디 또는 비밀번호가 잘못되었습니다.</p>
                                <div class='text-center'>
                                    <a href='login.php' class='btn btn-primary'>다시 시도</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>";
    }

    // 연결 종료
    $stmt->close();
    $conn->close();
}
?>
