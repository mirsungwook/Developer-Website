<?php
// 데이터베이스 연결 설정
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("데이터베이스 연결 실패: " . $conn->connect_error);
}

// POST 요청에서 데이터 가져오기
$room_name = $_POST['room_name'] ?? '';
$room_site = $_POST['room_site'] ?? '';
$room_cost = $_POST['room_cost'] ?? '';
$room_text = $_POST['room_text'] ?? '';
$room_image = $_FILES['room_image_data']['tmp_name'] ?? ''; // 파일의 임시 경로

// 이미지 파일을 BLOB로 읽어들임
$room_image_data = '';
if (!empty($room_image) && file_exists($room_image)) {
    $room_image_data = file_get_contents($room_image);
}

// SQL 쿼리 작성
$sql = "INSERT INTO room (room_name, room_site, room_cost, room_image, room_text) VALUES (?, ?, ?, ?, ?)";

// Prepared Statement 생성
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("오류: 쿼리를 준비하는 동안 오류가 발생했습니다.");
}

// 바인딩 및 실행
$stmt->bind_param("ssiss", $room_name, $room_site, $room_cost, $room_image_data, $room_text);
if (!$stmt->execute()) {
    die("오류: " . $stmt->error);
}

// 원룸 상품이 성공적으로 등록되었습니다를 출력
echo "원룸이 성공적으로 등록되었습니다. <br>";
echo '<a href="room.php">원룸 페이지로 돌아가기</a>'; // 원룸 페이지로 이동하기 버튼 출력

// Prepared Statement 종료
$stmt->close();

// 데이터베이스 연결 종료
$conn->close();
?>
