document.getElementById('chatButton').addEventListener('click', function() {
    document.getElementById('chatWindow').style.display = 'flex';
});

document.getElementById('closeChat').addEventListener('click', function() {
    document.getElementById('chatWindow').style.display = 'none';
});

const chatUsers = document.querySelectorAll('.chat-users .user');
chatUsers.forEach(user => {
    user.addEventListener('click', function() {
        const selectedUser = this.getAttribute('data-user');
        loadChatForUser(selectedUser);
    });
});

document.getElementById('sendChat').addEventListener('click', function() {
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    const message = chatInput.value;

    if (message.trim() !== '') {
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        messageElement.classList.add('user-message');
        chatMessages.appendChild(messageElement);

        // 로컬 스토리지에 메시지 저장
        const selectedUser = document.querySelector('.chat-users .user.active')?.getAttribute('data-user');
        if (selectedUser) {
            saveMessage(selectedUser, message);
        }

        chatInput.value = '';

        // 스크롤을 아래로 유지
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});

function loadChatForUser(user) {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = ''; // 기존 메시지 삭제

    // 로컬 스토리지에서 메시지를 불러오기
    const messages = JSON.parse(localStorage.getItem(user)) || [];
    messages.forEach(message => {
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        messageElement.classList.add('user-message');
        chatMessages.appendChild(messageElement);
    });
}

// 메시지를 로컬 스토리지에 저장하는 함수
function saveMessage(user, message) {
    const messages = JSON.parse(localStorage.getItem(user)) || [];
    messages.push(message);
    localStorage.setItem(user, JSON.stringify(messages));
}

// 스크롤 이벤트 리스너 추가
window.addEventListener('scroll', function() {
    let currentScroll = window.pageYOffset || document.documentElement.scrollTop;

    if (currentScroll > lastScrollTop) {
        // 아래로 스크롤할 때
        chatWidget.classList.add('fixed');
        chatWidget.classList.remove('relative');
    } else {
        // 위로 스크롤할 때
        chatWidget.classList.remove('fixed');
        chatWidget.classList.add('relative');
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
});