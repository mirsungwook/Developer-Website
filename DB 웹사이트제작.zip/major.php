<?php

header('Content-Type: application/json');

// 전달된 단과대학 ID를 가져옴
$college_id = intval($_GET['college_id']);

// 데이터베이스 연결
$conn = new mysqli('localhost', 'root', 'tjddnr6124', 'project');

// 연결 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 선택된 단과대학에 속한 학과들을 가져오는 SQL 쿼리
$query = "SELECT id, major FROM major WHERE college_id = $college_id";

// 쿼리 실행
$result = $conn->query($query);

// 쿼리 결과를 배열로 저장
$majors = array();
while ($row = $result->fetch_assoc()) {
    $majors[] = $row;
}

// JSON 형식으로 출력
echo json_encode($majors);

// 데이터베이스 연결 종료
$conn->close();
?>
