<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $pw = $_POST['pw'];

    $sql = "SELECT * FROM user WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($pw, $row['password'])) {
            $_SESSION['user_id'] = $row['user_id'];
            header('Location: buy.php');
            exit;
        } else {
            echo "<script>alert('아이디 또는 비밀번호가 잘못되었습니다.');</script>";
        }
    } else {
        echo "<script>alert('아이디 또는 비밀번호가 잘못되었습니다.');</script>";
    }

    $stmt->close();
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그인</title>

    <link rel="stylesheet" href="style_login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
     
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-title {
            margin-bottom: 30px;
        }
        .editor-note {
            margin-top: 20px;
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 4px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #274724;
            padding: 10px;
            color: #fff;
            height: 90px;
        }
        .navbar a {
            font-size: 20px;
            color: #fff;
            text-decoration: none;
            padding: 14px 20px;
        }
        .navbar .logo a {
            font-size: 24px;
        }
        .navbar a:hover {
            background-color: #d5e8d4;
            color: black;
        }
        .spacer {
            flex-grow: 1;
        }
        .card {
            margin-top: 35px;
        }
        .footer {
            background-color: #274724;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="logo">
            <a href="home.php">KONKUK UNIVERSITY</a>
        </div>
        <div class="spacer"></div>
        <ul class="nav-links">
            <li><a href="home.php">홈</a></li>
            <li><a href="buy.php">상품 구매</a></li>
            <li><a href="sell.php">상품 판매</a></li>
            <li><a href="share.php">나눔</a></li>
            <li><a href="room.php">원룸</a></li>
        </ul>
        <div class="spacer"></div>
        <ul class="user-links">
            <li><a href="login.php">로그인</a></li>
            <li><a href="signup.php">회원가입</a></li>
        </ul>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title text-center">로그인</h5>
                        <form action="login_process.php" method="post">
                            <div class="mb-3">
                                <label for="id" class="form-label">아이디</label>
                                <input type="text" class="form-control" id="id" name="id" required>
                            </div>
                            <div class="mb-3">
                                <label for="passwords" class="form-label">비밀번호</label>
                                <input type="password" class="form-control" id="passwords" name="passwords" required>
                            </div>
                            <button type="submit" class="btn btn-primary">로그인</button>
                            <a href="home.php" class="btn btn-secondary ms-2">홈으로 이동</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <footer class="footer">
        <p>&copy; 2024 장터 게시판. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
