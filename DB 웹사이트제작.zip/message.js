const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

mongoose.connect('mongodb://localhost/chat', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const sessionMiddleware = session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  store: MongoStore.create({ mongoUrl: 'mongodb://localhost/chat' })
});

app.use(sessionMiddleware);

io.use((socket, next) => {
  sessionMiddleware(socket.request, socket.request.res, next);
  next();
});

const ChatSchema = new mongoose.Schema({
  from: String,
  to: String,
  message: String,
  timestamp: Date
});

const Chat = mongoose.model('Chat', ChatSchema);

io.on('connection', (socket) => {
  const user = socket.request.session.user;
  if (!user) {
    return socket.disconnect();
  }

  socket.on('private_message', async ({ to, message }) => {
    const chat = new Chat({ from: user.username, to, message, timestamp: new Date() });
    await chat.save();
    io.to(to).emit('private_message', { from: user.username, message });
  });

  socket.on('join', (username) => {
    socket.join(username);
  });

  socket.on('delete_message', async ({ chatId }) => {
    await Chat.findByIdAndDelete(chatId);
  });

  socket.on('leave', (username) => {
    socket.leave(username);
  });
});

app.post('/login', (req, res) => {
  // 로그인 처리
  req.session.user = { username: req.body.username };
  res.redirect('/');
});

app.get('/messages', async (req, res) => {
  const user = req.session.user;
  if (!user) {
    return res.status(403).send('로그인이 필요합니다.');
  }
  const messages = await Chat.find({ $or: [{ from: user.username }, { to: user.username }] });
  res.json(messages);
});

server.listen(3000, () => {
  console.log('Server is running on port 3000');
});
