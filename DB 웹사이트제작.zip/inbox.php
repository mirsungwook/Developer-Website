<?php
session_start();
if (!isset($_SESSION['name'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_SESSION['name'];
$sql = "SELECT * FROM messages WHERE receiver = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>쪽지함</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>쪽지함</h1>
    <li><a href="buy.php">구매 페이지로 돌아가기</a></li>

    <?php if ($result->num_rows > 0): ?>
        <ul>
            <?php while($row = $result->fetch_assoc()): ?>
                <li>
                    <strong>보낸 사람:</strong> <?php echo htmlspecialchars($row['sender']); ?><br>
                    <strong>메시지:</strong> <?php echo htmlspecialchars($row['message']); ?><br>
                    <strong>보낸 시간:</strong> <?php echo $row['timestamp']; ?>

                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>쪽지가 없습니다.</p>
    <?php endif; ?>
    <?php
    $stmt->close();
    $conn->close();
    ?>
</body>
</html>
