<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 로그인 상태 확인
if (isset($_SESSION['name'])) {
    $user_id = $_SESSION['name'];
    // 사용자가 로그인한 경우, 사용자 식별 정보를 챗봇에 전달하여 해당 사용자를 식별합니다.
    echo "<script>const loggedInUser = '$user_id';</script>";
} else {
    // 사용자가 로그인하지 않은 경우, 로그인 페이지로 이동하도록 메시지를 표시합니다.
    echo "<script>if(confirm('로그인이 필요합니다. 로그인 페이지로 이동하시겠습니까?')) { window.location.href = 'login.php'; }</script>";
    // 이후의 코드 실행을 막습니다.
    exit;
}

$search_query = isset($_GET['query']) ? $_GET['query'] : '';
if (!empty($search_query)) {
    $sql = "SELECT * FROM room WHERE room_name LIKE '%$search_query%' OR room_site LIKE '%$search_query%'";
} else {
    // 검색어가 없는 경우 모든 상품을 가져옴
    $sql = "SELECT * FROM room";
}


$result = $conn->query($sql);

$items = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>원룸 정보</title>
    <link rel="stylesheet" href="style_room.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        /* 챗봇 위젯 버튼 스타일 */
        .chat-widget {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }

        .chat-button {
            width: 60px;
            height: 60px;
            background-color: #007bff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .chat-button img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
        }

        /* 챗봇 윈도우 스타일 */
        .chat-window {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 300px;
            height: 400px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: none;
            flex-direction: column;
        }

        .chat-header {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-header button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }

        .chat-body {
            display: flex;
            flex-direction: row;
            height: 100%;
        }

        .chat-users {
            width: 100px;
            border-right: 1px solid #ccc;
            overflow-y: auto;
        }

        .chat-users .user {
            padding: 10px;
            cursor: pointer;
        }

        .chat-users .user:hover {
            background-color: #f0f0f0;
        }

        .chat-messages {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
        }

        .chat-footer {
            display: flex;
            border-top: 1px solid #ccc;
        }

        .chat-footer input {
            flex: 1;
            padding: 10px;
            border: none;
            border-bottom-left-radius: 10px;
        }

        .chat-footer button {
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-bottom-right-radius: 10px;
        }

        .user-message {
            background-color: #007bff;
            color: white;
            padding: 8px;
            border-radius: 10px;
            margin: 5px 0;
            align-self: flex-end;
            max-width: 80%;
            word-wrap: break-word;
        }

        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 50px;
        }
        .room-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .room-item {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 0 0 20%;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 50px;
        }
        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-title {
            margin-bottom: 30px;
        }
        
    </style>
</head>

<script>
        // 검색 결과가 없는 경우 팝업 창으로 메시지 표시
        <?php if (empty($items) && !empty($search_query)): ?>
        window.onload = function() {
            alert("검색 결과가 없습니다.");
        }
        <?php endif; ?>
    </script>

<body>

<nav class="navbar">
    <div class="logo">
        <a href="home.php">KONKUK UNIVERSITY<br></a>
    </div>
    <div class="spacer"></div>
    <ul class="nav-links">
        <li><a href="home.php">홈</a></li>
        <li><a href="buy.php">상품 구매</a></li>
        <li><a href="sell.php">상품 판매</a></li>
        <li><a href="share.php">나눔</a></li>
        <li><a href="room.php">원룸</a></li>
    </ul>
    <div class="spacer"></div>
    <ul class="user-links">
        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li><a style="margin-right: -35px; color: white;">환영합니다! <?php echo $_SESSION['name']; ?>님</a></li>
            <li><a class="logout-link" onclick="location.href='logout.php'">[로그아웃]</a></li>
        <?php else: ?>
            <li><a href="login.php">로그인</a></li>
            <li><a href="signup.php">회원가입</a></li>
        <?php endif; ?>
    </ul>
</nav>

<div class="container">
    
   <a href="submit_room.php" class="btn btn-primary register-btn">원룸 등록하기</a>
   
</div>

<div id="productList" class="container mt-4">
<div class="search-bar">
        <form action="room.php" method="GET">
            <input type="text" name="query" placeholder="원룸 이름 또는 장소를 입력하세요">
            <button type="submit">검색</button>
        </form>
    </div>



<div id="roomList" class="container mt-4">
    <div class="row">
        <?php foreach ($items as $item): ?>
            <div class="col-md-3 mb-4">
                <div class="card grid-item">
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($item['room_image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($item['room_name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title">상품명: <?php echo htmlspecialchars($item['room_name']); ?></h5>
                        <p class="card-text">장소: <?php echo htmlspecialchars($item['room_site']); ?></p>

                        <p class="card-text">가격: <?php echo number_format(htmlspecialchars($item['room_cost'])); ?>원</p>
                        <p class="card-text">상품 상세설명: <?php echo htmlspecialchars($item['room_text']); ?></p>

                        <a href="#" class="btn btn-primary">구매하기</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>


<footer class="footer">
    <p>&copy; 2024 장터 게시판. All Rights Reserved.</p>
    </footer>
         <!-- 챗봇 위젯 -->
    <div class="chat-widget">
        <div class="chat-button" id="chatButton">
            <img src="https://search.pstatic.net/sunny/?src=https%3A%2F%2Fpreview.files.api.ogq.me%2Fv1%2Fpreview%2FIMAGE%2F7f527e5f%2F5d5c0f5e725f7%2F084449813.jpg%3Fformat%3Dw1280_cc&type=a340" alt="Chat Icon">
        </div>
        <div class="chat-window" id="chatWindow">
            <div class="chat-header">
                <span>쪽지</span>
                <button id="closeChat">&times;</button>
            </div>
            <div class="chat-body">
                <div class="chat-users" id="chatUsers">
                    <!-- 채팅 대상 목록 -->
                    <div class="user" data-user="user1">사용자 1</div>
                    <div class="user" data-user="user2">사용자 2</div>
                    <!-- 추가 사용자들 -->
                </div>
                <div class="chat-messages" id="chatMessages">
                    <!-- 채팅 메시지 -->
                </div>
            </div>
            <div class="chat-footer">
                <input type="text" placeholder="메시지를 입력하세요..." id="chatInput">
                <button id="sendChat">보내기</button>
            </div>
            <script>
        document.getElementById('chatButton').addEventListener('click', function() {
            document.getElementById('chatWindow').style.display = 'flex';
        });

        document.getElementById('closeChat').addEventListener('click', function() {
            document.getElementById('chatWindow').style.display = 'none';
        });

        const chatUsers = document.querySelectorAll('.chat-users .user');
        chatUsers.forEach(user => {
            user.addEventListener('click', function() {
                const selectedUser = this.getAttribute('data-user');
                loadChatForUser(selectedUser);
            });
        });

        document.getElementById('sendChat').addEventListener('click', function() {
            const chatInput = document.getElementById('chatInput');
            const chatMessages = document.getElementById('chatMessages');
            const message = chatInput.value;

            if (message.trim() !== '') {
                const messageElement = document.createElement('div');
                messageElement.textContent = message;
                messageElement.classList.add('user-message');
                chatMessages.appendChild(messageElement);

                // 로컬 스토리지에 메시지 저장
                const selectedUser = document.querySelector('.chat-users .user.active')?.getAttribute('data-user');
                if (selectedUser) {
                    saveMessage(selectedUser, message);
                }

                chatInput.value = '';

                // 스크롤을 아래로 유지
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        });

        function loadChatForUser(user) {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = ''; // 기존 메시지 삭제

            // 로컬 스토리지에서 메시지를 불러오기
            const messages = JSON.parse(localStorage.getItem(user)) || [];
            messages.forEach(message => {
                const messageElement = document.createElement('div');
                messageElement.textContent = message;
                messageElement.classList.add('user-message');
                chatMessages.appendChild(messageElement);
            });
        }

        // 메시지를 로컬 스토리지에 저장하는 함수
        function saveMessage(user, message) {
            const messages = JSON.parse(localStorage.getItem(user)) || [];
            messages.push(message);
            localStorage.setItem(user, JSON.stringify(messages));
        }

        // 스크롤 이벤트 리스너 추가
        window.addEventListener('scroll', function() {
            let currentScroll = window.pageYOffset || document.documentElement.scrollTop;

            if (currentScroll > lastScrollTop) {
                // 아래로 스크롤할 때
                chatWidget.classList.add('fixed');
                chatWidget.classList.remove('relative');
            } else {
                // 위로 스크롤할 때
                chatWidget.classList.remove('fixed');
                chatWidget.classList.add('relative');
            }
            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;

            document.querySelector('form').addEventListener('submit', function(event) {
            event.preventDefault(); // 기본 동작인 폼 제출 막기

            let filter = document.getElementById('searchInput').value.toUpperCase();
            let productList = document.getElementById('productList');
            let cards = productList.getElementsByClassName('card');

            for (let i = 0; i < cards.length; i++) {
                let cardTitle = cards[i].getElementsByClassName('card-title')[0];
            if (cardTitle) {
                let titleText = cardTitle.textContent || cardTitle.innerText;
            if (titleText.toUpperCase().indexOf(filter) > -1) {
                cards[i].style.display = ""; // 검색어와 일치하는 상품 보이기
            } else {
                cards[i].style.display = "none"; // 검색어와 일치하지 않는 상품 숨기기
            }
        }
    }
});

// 검색 이벤트를 처리하는 함수
function handleSearch(event) {
    event.preventDefault(); // 기본 이벤트(폼 제출) 방지

    let filter = document.getElementById('searchInput').value.toUpperCase();
    let productList = document.getElementById('productList');
    let cards = productList.getElementsByClassName('card');

    for (let i = 0; i < cards.length; i++) {
        let cardTitle = cards[i].getElementsByClassName('card-title')[0];
        if (cardTitle) {
            let titleText = cardTitle.textContent || cardTitle.innerText;
            if (titleText.toUpperCase().indexOf(filter) > -1) {
                cards[i].style.display = ""; // 검색어와 일치하는 상품 보이기
            } else {
                cards[i].style.display = "none"; // 검색어와 일치하지 않는 상품 숨기기
            }
        }
    }
}

// 검색 폼과 검색 버튼에 이벤트 리스너 추가
document.querySelector('form').addEventListener('submit', handleSearch);
document.querySelector('form button').addEventListener('click', handleSearch);

        });
        
    </script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>