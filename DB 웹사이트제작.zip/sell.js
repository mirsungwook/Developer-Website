// scripts.js
function submitProduct() {
    const productForm = document.getElementById('productForm');
    const formData = new FormData(productForm);
    const productName = formData.get('productName');
    const productDescription = formData.get('productDescription');
    const productPrice = formData.get('productPrice');
    const productImage = formData.get('productImage');
    
    if (productImage && productName && productDescription && productPrice) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const productHTML = `
                <div class="product">
                    <img src="${e.target.result}" alt="${productName}" style="width: 100px; height: 100px;">
                    <h2>${productName}</h2>
                    <p>${productDescription}</p>
                    <p>가격: ${productPrice}원</p>
                </div>
            `;
            document.getElementById('productList').innerHTML += productHTML;
        };
        reader.readAsDataURL(productImage);
    } else {
        alert('모든 필드를 채워주세요.');
    }
}


// scripts.js

const existingProductCodes = ["ABC123", "XYZ456", "DEF789"]; // 예제용 기존 상품 코드

function checkDuplicateCode() {
    const productCodeInput = document.getElementById('productCode');
    const duplicateCheckResult = document.getElementById('duplicateCheckResult');
    const productCode = productCodeInput.value;

    if (existingProductCodes.includes(productCode)) {
        duplicateCheckResult.textContent = '이 상품 코드는 이미 사용 중입니다.';
        duplicateCheckResult.style.color = 'red';
    } else {
        duplicateCheckResult.textContent = '이 상품 코드는 사용 가능합니다.';
        duplicateCheckResult.style.color = 'green';
    }
}

function submitProduct() {
    const productForm = document.getElementById('productForm');
    const formData = new FormData(productForm);
    const productName = formData.get('productName');
    const productPrice = formData.get('productPrice');
    const productCode = formData.get('productCode');
    const productSummary = formData.get('productSummary');
    const productImage = formData.get('productImage');
    const productDescription = formData.get('productDescription');

    if (productImage && productName && productPrice) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const productHTML = `
                <div class="product mt-4 p-3 border rounded">
                    <img src="${e.target.result}" alt="${productName}" style="width: 100px; height: 100px;">
                    <h2>${productName}</h2>
                    <p>${productSummary}</p>
                    <p>가격: ${productPrice}원</p>
                    <p>${productDescription}</p>
                </div>
            `;
            document.getElementById('productList').innerHTML += productHTML;
        };
        reader.readAsDataURL(productImage);
    } else {
        alert('필수 필드를 채워주세요.');
    }
}

function previewProduct() {
    alert("미리보기 기능은 구현되지 않았습니다.");
}

function clearForm() {
    document.getElementById('productForm').reset();
}
