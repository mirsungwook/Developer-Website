<?php
// 데이터베이스 연결 설정
$servername = "localhost";
$username = "root";
$password = "tjddnr6124";
$dbname = "project";

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("데이터베이스 연결 실패: " . $conn->connect_error);
}

// POST 요청에서 데이터 가져오기
$product_name = isset($_POST['product_name']) ? $_POST['product_name'] : '';
$cost = isset($_POST['cost']) ? $_POST['cost'] : '';
$product_code = isset($_POST['product_code']) ? $_POST['product_code'] : '';
$summary = isset($_POST['summary']) ? $_POST['summary'] : '';
$product_text = isset($_POST['product_text']) ? $_POST['product_text'] : '';
$seller= isset($_POST['seller']) ? $_POST['seller'] : '';

// 파일 업로드 처리
if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == UPLOAD_ERR_OK) {
    $product_image = $_FILES['product_image']['tmp_name'];
    $product_image_data = addslashes(file_get_contents($product_image));
} else {
    $product_image_data = null;
    echo "Error: 상품 이미지를 업로드하는데 문제가 발생했습니다.";
    exit;
}

// SQL 쿼리 작성
$sql = "INSERT INTO product (product_name, cost, product_code, summary, product_image, product_text, seller) 
        VALUES('$product_name', '$cost', '$product_code', '$summary', '$product_image_data', '$product_text', '$seller')";

// 쿼리 실행 및 결과 확인
if ($conn->query($sql) === TRUE) {
    echo "판매 상품이 성공적으로 등록되었습니다. <br>";
    echo '<a href="buy.php">구매 페이지로 돌아가기</a>';
} else {
    echo "오류: " . $sql . "<br>" . $conn->error;
}

// 데이터베이스 연결 종료
$conn->close();
?>
